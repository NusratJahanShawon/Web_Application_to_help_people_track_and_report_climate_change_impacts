function goToHome() {
    window.location.href = 'home.html'; // Replace 'your-home-page.html' with the actual URL of your home page
}
